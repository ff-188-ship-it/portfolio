 <?php
 // fichier contenant les constantes de connexion
 define('LOGIN', "franck.ahouangassi"); // mettre ici votre login MariaDB)
 define('PASSE', "178900Azer@"); // mettre ici votre mot de passe MariaDB
 define('SERVEUR', "mi-mariadb.univ-tlse2.fr"); // le nom du serveur mariaDB(ici, c’est le serveur du DMI)
 define('BASE', "24_1L2_franck_ahouangassi"); // mettre le nom de la BD sur laquelle vous voulez effectuer des requêtes (24_ETU… ?)
 ?>
